# Karol Burczyk
# Program na zaliczenie przedmiotu Programowanie Obiektowe

# plik ze stałymi

# wysokość grafiki tła
BG_HEIGHT = 384

# wartość skoku ptaka przy wciśnięciu spacji
BIRD_JUMP = 35

# wartość spadku ptaka
BIRD_FALL = 8

# wartość "ticku" zegara
CLOCK_TICK = 120

